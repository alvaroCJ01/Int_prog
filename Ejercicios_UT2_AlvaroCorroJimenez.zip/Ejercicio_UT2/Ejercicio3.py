cad='C:\\Users\\alumno\\Desktop\\proyecto'
a=cad.find('C')
b=cad.find('alumno')
c=cad.find('Desktop')
d=len('Desktop')
print(cad[a:a+1])
print(cad[b:c-1])
print(cad[c:c+d])