frase_inic=' pc -- aula - 07 \n'
frase=frase_inic.strip().upper().replace('-','',1).replace(' ','')
print(frase)