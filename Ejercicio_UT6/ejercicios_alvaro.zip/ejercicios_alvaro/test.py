import modulo_alvaro

modulo_alvaro.mayor(1,2)

modulo_alvaro.es_par(2)

modulo_alvaro.es_mayusculas("ASDAD")

modulo_alvaro.potencia(2,2)

modulo_alvaro.ordena_mayor_menor(2,3,4)

modulo_alvaro.clasifica_circunferencias(1,1,1,2,2,2)

modulo_alvaro.clasifica_triangulo(1,2,3)

modulo_alvaro.es_bisiesto(300)

modulo_alvaro.es_fecha_correcta(20,10,200)

modulo_alvaro.calcula_ganancias_uva(10,10,"A",2)

modulo_alvaro.costes_viaje(20)

modulo_alvaro.coste_llamada(20,"S","T")

modulo_alvaro.dia_escrito(2)

modulo_alvaro.num_dias_mes(2)

modulo_alvaro.calcula_coste_transporte(100,1)

modulo_alvaro.factorial(2)

modulo_alvaro.pares_entre(1,2)

modulo_alvaro.tabla_multiplicar(2)

modulo_alvaro.adivina_numero(2)

modulo_alvaro.es_primo(2)

modulo_alvaro.prineros_primos(2)